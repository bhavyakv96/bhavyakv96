import React from 'react';
import { SafeAreaView, View, FlatList, StyleSheet, Text, TouchableOpacity, Alert, Button,navigation } from 'react-native';
//import DATA from './data.json';

const DATA = [
  {
 "id":101,
  "name":"Asha",
  "email":"asha@test.com"    
},
{
  "id":102,
  "name":"Bhavya",
  "email":"bhavya@test.com"  
},
{
  "id":103,
  "name":"Chandra",
  "email":"chandra@test.com"  
},
{
    "id":104,
    "name":"Devi",
    "email":"devi@test.com" 
}
];

function Item({id}){
    const handlePress=(id)=>{
        const emp=DATA.find((details)=>{
            return details.id===id;
    });

    Alert.alert(
        "Employee Details \n",
       `Id   : ${emp.id} \n
        Name  : ${emp.name} \n
        Email : ${emp.email}`
    );
    };
   
return (    
<>
  <TouchableOpacity
  onPress={()=>handlePress(id)}
  style={styles.item}>
     {/* onPress={()=>navigation.navigate('ApiDataInfo1')} title="Info">  */}
    <Text style={styles.title}>{id}</Text>
  </TouchableOpacity>
   </>
    );
}

// const App=(props)=>{
//     const{navigate}=props.navigation;
//     nextScreen=()=>{
//         return navigate('ApiData');
//     }

const App = (navigation) => {    
//   return(
//     <Item 
//     item={item}
//     onPress={()=> 
//         navigation.navigate('ApiData2',{data: item})}
//     />
//   );
  return (
    <View style={styles.container}>
        <Text style={styles.list}>List of employee Id's : </Text>
      <FlatList
        data={DATA}
        renderItem={({item})=>(
          <Item {...item} />  
      )}/>
      <Button onPress={() => navigation.navigate('ApiDataInfo1')} title="Details" /> 
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 2,
  },
  item: {
    alignItems:'center',
    //backgroundColor: '#D5D6EA',
   // backgroundColor:'#FCDFFF',
    backgroundColor:'#EBDDE2',
    padding: 20,
    marginVertical: 8,
     marginHorizontal: 25,
  },
  title: {
    color:'black',
    fontSize:18,
    fontWeight:'bold', 
 },
 renItem:{
    alignItems:'center',
    justifyContent:'center'
 },
 list:{
   fontSize:20,
   paddingBottom:20,
   paddingTop:20,
   fontStyle:'italic',
   alignSelf:'center',                                                
 }
});
export default App;