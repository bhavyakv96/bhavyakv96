import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
// import BTabsTask2 from './BTabsTask2';

const BTabsTask1 = ({navigation}) => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={styles.container}>
        <Text style={{alignSelf: 'center', fontSize: 24, color: '#7D0552'}}>
          Welcome to
        </Text>
        <Text style={{alignSelf: 'center', fontSize: 30, color: '#AA6C39'}}>
          Imaginnovate!!!!
        </Text>
      </View>
      <View style={styles.container1}>
        <TouchableOpacity onPress={() => navigation.navigate('AboutUs')}>
          <Text style={styles.b1}>AboutUs</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('LogIn')}>
          <Text style={styles.b1}>Login</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
          <Text style={styles.b1}>SignUp</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 12,
    //backgroundColor: 'powderblue',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container1: {
    flex: 1,
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignSelf: 'center',
  },

  b1: {
    margin: 8,
    padding: 8,
    //borderRadius: 6,
    width: 140,
    height: 50,
    backgroundColor: 'powderblue',
    fontSize: 20,
  },
});
export default BTabsTask1;
