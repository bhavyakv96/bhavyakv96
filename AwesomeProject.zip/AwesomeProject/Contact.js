import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';

const Contact = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.mainHeader}>LOGIN FORM</Text>

      <View style={styles.loginFormContainer}>
        <TextInput style={styles.inputStyle} placeholder="UserName" />

        <TextInput
          style={styles.inputStyle}
          placeholder="Password"
          secureTextEntry
          maxLength={6}
        />

        <View style={styles.actionBtnsContainer}>
          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => alert('LogIn Works')}>
            <Text style={styles.btnTxt}>LOG-IN</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => alert('SignUp Works')}>
            <Text style={styles.btnTxt}>SIGN-UP</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingTop: 100,
    paddingHorizontal: 0,
    marginTop:150
  },
  mainHeader: {
    fontSize: 30,
    fontWeight: '500',
    color: '#344055',
    backgroundColor: '#fff',
    paddingBottom: 30,
    paddingTop: 30,
  },
  loginFormContainer: {
    marginTop: 20,
    width: '90%',
    padding: 15,
    marginBottom: 10,
  },

  inputStyle: {
    borderWidth: 1,
    borderColor: '#000000',
    borderRadius: 1,
    fontSize: 18,
    color: '#000000',
    padding: 15,
    marginBottom: 10,
    height: 50,

  },
  actionBtnsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionBtn: {
    flex: 1,
    backgroundColor: '#a9a9a9',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnTxt: {
    fontSize: 12,
    color: '#000000',
    
  },
});

export default Contact;
