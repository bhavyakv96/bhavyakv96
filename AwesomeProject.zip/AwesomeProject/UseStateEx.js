import React,{useState} from 'react';
import { Button, StyleSheet,Text,View } from 'react-native';

export default function UseStateEx(){
    const[name,setName]=useState('A');
    const[person,setPerson]=useState({name:'John',age:20})

    const clickHandler=()=>{
        setName('B');
        setPerson({name:'Anu',age:15});
    }
    return(
        <View style={styles.container}>
            <Text> My name is {name}</Text>
            <Text>His name is {person.name} and age is {person.age}</Text>
            <View style={styles.btnCont}></View>
            <Button title='Update' onPress={clickHandler}/>
            </View>
    );
}

const styles=StyleSheet.create({
    container:{
        flex:1,
        alignItems:'center',
        justifyContent:'center'
    },
    btnCont:{

    }


})