import React from 'react';
import {SafeAreaView} from 'react-native';
import Flex from './F';
import FlexEx1 from './FlexEx1';
import FlexExam from './FlexExam';
import FlexExam1 from './FlexExam1';
import PropsEx from './PropsEx';
import Screen1 from './Screen1';
import Screen2 from './Screen2';
import TodoList from './TodoList';
import ApiData from './FlatList';
import ApiDataInfo1 from './Navigate1';
//import ApiData2 from './Navigate';
import RadioBtn from './RadioBtn';
//import App from './Examples';
import Task from './Task';
import A from './TodoUsingFlatListA';
import UseStateEx from './UseStateEx';
import Test1 from './Test1';
import TabsTask1 from './BTabsTask1';
import HomeScreen from './BTabsTask2';
import Modal from './Modal';
import BottomTabs from './BottomTabs';

const App = () => {
  return (
    <>
      <SafeAreaView style={{flex: 1}}>
        <BottomTabs />
      </SafeAreaView>
    </>
  );
};
export default App;

// import React from 'react';
// import {NavigationContainer} from '@react-navigation/native';
// import {createNativeStackNavigator} from '@react-navigation/native-stack';

// import BTabsTask1Screen from './BTabsTask1';
// import BTabsTask2Screen from './BTabsTask2';
// import BTabsTask3Screen from './BTabsTask3';
// import BTabsTask4Screen from './BTabsTask4';

// const Stack = createNativeStackNavigator();
// const MyStack = () => {
//   return (
//     <NavigationContainer>
//       <Stack.Navigator>
//         <Stack.Screen
//           name="Home"
//           component={BTabsTask1Screen}
//           options={{title: 'Imaginnovate'}}
//         />
//         <Stack.Screen name="AboutUs" component={BTabsTask2Screen} />
//         <Stack.Screen name="LogIn" component={BTabsTask3Screen} />
//         <Stack.Screen name="SignUp" component={BTabsTask4Screen} />
//       </Stack.Navigator>
//     </NavigationContainer>
//   );
// };
// export default MyStack;
