import React, { Component } from 'react';
import {View,StyleSheet,ImageBackground,Text, TouchableOpacity,navigation,navigate, ActivityIndicator} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {withNavigation } from "react-navigation";

    export default class Screen1 extends Component{

    ComponentDidMount(){
        setTimeout(() => {
            this.props.navigation.navigate("Screen2")
        },2000);
    }
    render(){
        return(
           
            <View style={{flex:1}}>
                <View style={styles.container}>
                 <ImageBackground 
               source={require('./images/img.jpeg')} 
               style={{flex:1,resizeMode:'Cover'}}blurRadius={4}/>
                <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center'}}>
          <TouchableOpacity 
        //    onPress={() => navigation.navigate('Screen2')}>
         onPress={()=> this.props.navigation.navigate('Screen2')}>
            <Text
            style={styles.msg}>
                Imaginnovate</Text></TouchableOpacity>

                {/* <ActivityIndicator size="large" color='blue' style={{margin:10}}/> */}
        </View>
        </View>
        </View>

       ) };
      };
const styles=StyleSheet.create({
    container:{
        flex:1,
    },
   msg:{
    //height:100,
    fontSize:30,
    color:'black',
    fontWeight:'800'      
   },
   image:{
    flex:1,
    resizeMode:'Cover',
    blurRadius:4,
   }
})

//export default Screen1;
