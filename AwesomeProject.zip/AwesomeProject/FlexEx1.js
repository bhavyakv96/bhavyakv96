import react from 'react';
import {View,Text,StyleSheet, SafeAreaView} from 'react-native';

const FlexEx1 = ()=>{
    return(
        <SafeAreaView style={{flex:1,}}>
        <View>
            <View style={styles.container1}>
            <View style={styles.c1}></View>
            <View style={styles.c2}></View>
            </View>
            <View style={styles.container2}>
            <View style={styles.c3}></View>
            <View style={styles.c4}></View>
            </View>
        </View>
        </SafeAreaView>
    );
};
const styles=StyleSheet.create({
    c1:{
        width:54,
        height:54,
        backgroundColor:'skyblue',
        alignSelf:'flex-end'
    },
    c2:{
        width:54,
        height:54,
        backgroundColor:'pink',
        alignSelf:'center'
    },
     c3:{
        width:54,
        height:54,
        backgroundColor:'red',
        // flexDirection:'column',
        // justifyContent:'space-between'
    },
     c4:{
        width:54,
        height:54,
        backgroundColor:'green'
    },
    container1:{
        flex:1,
        backgroundColor:'yellow'
        
    },
    container2:{
        flex:1,
        flexDirection:'column',
        alignItems:'flex-start',
        justifyContent:'space-between',
        backgroundColor:'blue'
      
    }

});
export default FlexEx1;