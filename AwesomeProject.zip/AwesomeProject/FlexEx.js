/*import React from "react";
import {View,Text,StyleSheet} from "react-native";
const FLexEx = ()=>{
    return(
        <View>
            <View style={styles.cont1}>
            <Text>This is 1</Text>
       </View>

       <View style={styles.cont2}>
        <Text>this is 2</Text>
       </View>

       <View style={styles.cont3}>
        <Text>this is 3</Text>
       </View>
        </View>
    );
};

const styles=StyleSheet.create({
    cont1:{
        flex:1,
        backgroundColor:'green',
        color:'black'
    },
    cont2:{
        flex:2,
        backgroundColor:'red',
    },
    cont3:{
        flex:3,
        backgroundColor:'blue',
    }
});
export default FLexEx;

import React from "react";
import { StyleSheet, Text, View } from "react-native";

const FlexEx = () => {
  return (
<>
<View style={{ backgroundColor: "#7cb48f", flex: 1, flexDirection:"row" }} />
<View style={{ backgroundColor: "#7CA1B4", flex: 1,flexDirection:"row"  }} />
</>
 );
  }
export default FlexEx;*/



/*import React from "react";
import { SafeAreaView, StyleSheet, View } from "react-native";

export default function FlexEx() {
  return (
    <>
      <View style={styles.container} >
        <View style={styles.square} />
        <View style={styles.square} />
        <View style={styles.square}  />

      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#7CA1B4",
    flex: 3,
    alignItems: "center", 
    justifyContent: "center",
    flexDirection: "row"
    
  },
  square: {
    backgroundColor: "#7cb48f",
    width: 100,
    height: 100,
    margin: 4,
  },
});*/

{/*import React, { Component } from 'react';
import { SafeAreaView, View ,Text} from 'react-native';

export default class FlexEx extends Component {
  render() {
    return (
        <SafeAreaView>
      <View style={{flex:1, flexDirection: 'row'}}>
        <View style={{width: 50, height: 50, backgroundColor: 'powderblue'}} />
        <View style={{width: 50, height: 50, backgroundColor: 'skyblue'}} />
     {/*  <View style={{width: 50, height: 50, backgroundColor: 'steelblue',}} />*

       <View style={{flex:1,width:50,height:50,backgroundColor:'powderblue',marginLeft:200,justifyContent:'flex-end'}}>
        
      </View>
      </View>
      </SafeAreaView>

     
    );
  }
};*/}



import React, { Component } from 'react';
import { SafeAreaView, View ,Text,StyleSheet} from 'react-native';

export default class FlexEx1 extends Component {
  render() {
    return (
        <SafeAreaView>
      <View style={{flex:1, flexDirection: 'row'}}>
        <View style={{width: 50, height: 50, backgroundColor: 'powderblue'}} />
        <View style={{width: 50, height: 50, backgroundColor: 'skyblue'}} />
       <View style={{width:50,height:50,backgroundColor:'powderblue',marginLeft:240}}/> 
      <View style={styles.b1}/>
      </View>

      <View style={styles.b2}>
        <View style={{width: 50, height: 50, backgroundColor: 'black'}}/>
        <View style={{width: 50, height: 50, backgroundColor: 'blue'}} />
        <View style={{width: 50, height: 50, backgroundColor: 'red'}} />


      </View>

      </SafeAreaView>

     
    );
  }
};
const styles=StyleSheet.create({
    b1:{
        // width:50,
        // height:50,
       // backgroundColor:'steelblue',
       // flexDirection:'column',
       // alignSelf:'center'
    },
    b2:{
        flexDirection:'column',
        justifyContent:'space-between',
        alignItems:'flex-end'

    }
});


