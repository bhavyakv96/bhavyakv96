import React from 'react';
import {StyleSheet, View} from 'react-native';
export default function App() {
  return (
    <View style={styles.mainContainer}>
      <View style={styles.container1}>
        <View style={styles.box1} />
        <View style={styles.box2} /> 
        <View style={styles.box3} />
      </View>
      <View style={styles.container2}>
        <View style={styles.box4} />
        <View style={styles.box5} />
      </View>
      <View style={styles.container3}>
        <View style={styles.box6} />
        <View style={styles.box7} />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
    mainContainer:{
        flex:3,
    },
    container1: {
        flex:1,
      flexDirection: 'row',
      backgroundColor:'aliceblue'
    },
    box1: {
        backgroundColor:'steelblue',
       // alignSelf: 'flex-end',
        width: 50,
        height: 50,
        margin: 4,
      },
      box2: {
        backgroundColor: 'slategrey',
        width: 50,
        height: 50,
        margin: 4,
      },
      box3: {
        backgroundColor:'steelblue',
        marginLeft:220,
        width: 50,
        height: 50,
        margin: 4,
      },
      container2: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-around',
        backgroundColor:'white'
      },
      box4: {
        backgroundColor: 'darkturquoise',
        alignSelf: 'center',
        width: 50,
        height: 50,
        margin: 4,
      },
      box5: {
        backgroundColor: 'darkturquoise',
       alignSelf: 'center',
        width: 50,
        height: 50,
        margin: 4,
      },
      container3: {
        flex: 1,
        flexDirection: 'row',
       justifyContent: 'space-between',
        backgroundColor:'azure'
      },
      box6: {
        backgroundColor: 'skyblue',
        alignSelf: 'flex-end',
        width: 50,
        height: 50,
        margin: 4,
      },
      box7: {
        backgroundColor: 'skyblue',
        alignSelf: 'flex-end',
        width: 50,
        height: 50,
        margin: 4,
      },
    });
