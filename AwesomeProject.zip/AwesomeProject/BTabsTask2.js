import React from 'react';
import {View, Text, StyleSheet, SafeAreaView} from 'react-native';

const BTabsTask2 = () => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={styles.container}>
        <Text style={styles.heading}>Our Story</Text>
      </View>
      <View style={styles.container1}>
        <Text style={styles.mainText}>
          Founded in 2013, Imaginnovate quickly grew from a single client and a
          single developer to a full-service digital solution, strategy, and
          development team. We are inspired by the evolution of technology and
          the pursuit of innovation, while being grounded in a passion for
          potential applications within today’s supply chain industry. In
          working with some of the industry’s biggest names, we’ve had the
          opportunity to encounter unique circumstances, tackle groundbreaking
          projects and develop a deep understanding of the particular struggles
          many transportation and logistics industry technology projects face.
        </Text>
      </View>
    </SafeAreaView>
  );
};
export default BTabsTask2;

const styles = StyleSheet.create({
  heading: {
    fontSize: 24,
    color: '#7D0552',
    height: 30,
  },
  container: {
    flex: 1,
    backgroundColor: 'powderblue',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  container1: {
    flex: 10,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  mainText: {
    flex: 1,
    fontsize: 15,
  },
});
