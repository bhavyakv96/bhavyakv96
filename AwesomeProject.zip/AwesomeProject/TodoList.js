import React from 'react';
import { View,Text,StyleSheet } from 'react-native';
import TodoListCont from './TodoListCont';

export default function TodoList (){
    return(
        <View style={styles.container}>
            <View style={styles.tasks}>
            <Text style={styles.mainText}>Languages!!</Text>
            <View style={styles.items}>
                <TodoListCont text={'C'}/>
                <TodoListCont text={'Java'}/>
                <TodoListCont text={'React'}/>

                </View>
            </View>
        </View>
    );
}
const styles=StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#E3E4FA',
    },
    mainText:{
        color:'black',
        fontSize:18,
        fontWeight:'bold',
    },
    items:{
        marginTop:30,
    },
    tasks:{
        paddingTop:80,
        paddingHorizontal:20,
    }
})