import React from 'react';
import {View,Text,TextInput,StyleSheet,TouchableOpacity,navigation} from 'react-native';
import styles from './Screen2Style';

const Screen2=()=>{
    return(
        <>
        <View style={styles.container1}>
            <Text style={styles.msg}>
                Imaginnovate
             </Text>
        </View>
        <View style={styles.container2}>
        <TextInput style={styles.inputStyle} placeholder="Email Address" />

         <TextInput
             style={styles.inputStyle}
              placeholder="Password"
               secureTextEntry
               maxLength={6}/>

             <TouchableOpacity
            style={styles.loginBtn}>
            {/*onPress={() => alert('LogIn Works')}*/}
            <Text style={{color:'white',}}>LOG-IN</Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={{color:'#3F414E',alignSelf:'center'}}>Forgot Password ?</Text>
          </TouchableOpacity>


        </View>
        <View style={styles.container3}>
            <Text style={{color:'grey',marginBottom:50}}>
                ALREADY HAVE AN ACCOUNT ?

             <TouchableOpacity>
            <Text style={{color:'#0AA6FE',fontSize:17,marginTop:5}}>  SignUp</Text>
          </TouchableOpacity>

          </Text>
          </View>    
        </>

    );
};
   
export default Screen2;