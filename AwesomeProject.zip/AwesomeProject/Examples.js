import React ,{useState} from 'react';
import {View,Text, ActivityIndicator,StyleSheet, SafeAreaView,TextInput, Image, Switch, ScrollView,StatusBar} from 'react-native';

const image={uri: "https://www.123rf.com/photo_141437201_pale-light-blue-plain-background.html"}

const Examples=()=>{

const [isEnabled, setIsEnabled] = useState(false);
const toggleSwitch = () => setIsEnabled(previousState => !previousState);
return(
    <SafeAreaView>
         <ScrollView>
    <View styles={[styles.container,styles.horizontal]}>
        <Text style={styles.heading}>ActivityIndicator</Text>
        <ActivityIndicator size="large" color="green" />
        <ActivityIndicator/>
        {/* <ActivityIndicator size="small" color="blue" /> */}



     <Text style={styles.heading}>Image</Text>
        <Image
        style={{height:50,width:50}}
        source={{
       uri : 'https://reactnative.dev/img/tiny_logo.png',
        }}/>

      
      <Text style={styles.heading}>ScrollView</Text>
      <ScrollView style={styles.scrollview}>
        <Text>
        Lorem Ipsum is simply dummy text 
        of the printing and 
        typesetting industry. Lorem Ipsum 
        has been the industry's standard
         dummy text ever since the 1500s, 
         when an unknown printer took a galley 
         of type and scrambled it to make a
          type specimen book. It has survived
          not only five centuries, but also 
          the leap into electronic typesetting,
           remaining essentially unchanged.
            It was popularised in the 1960s with 
           the release of Letraset sheets 
           containing Lorem Ipsum passages, and 
           more recently with desktop publishing
            software like Aldus PageMaker 
           including versions of Lorem Ipsum.
        </Text>
          </ScrollView>


      <View >
        <Text style={styles.heading}>Switch</Text>
      <Switch
        trackColor={{ false: "yellow", true: "powderblue" }}
        thumbColor={isEnabled ? "yellow" : "#FCDFFF"}
        ios_backgroundColor="black"
        onValueChange={toggleSwitch}
        value={isEnabled} />
    
        <Text>{isEnabled.toString()}</Text>
        <Text>{isEnabled && 'Activated'}</Text>
  
    </View>


  <Text style={styles.heading}>Text Input</Text>
    <TextInput
        style={styles.input}
        placeholder='Enter Name'
      />







        </View>
        </ScrollView>
    </SafeAreaView>
)
};

   
const styles=StyleSheet.create({

    container:{
        flex:1,
        justifyContent:'center',
        paddingTop:StatusBar.currentHeight,
 },
 heading:{
    fontSize:18,
    fontWeight:'bold',
    alignSelf:'center'

 },
    horizontal:{
        flexDirection:'row-reverse',
        justifyContent:'space-around',
        padding:10,

    },
    scrollview:{
        backgroundColor:'powderblue',
        marginHorizontal:30,
        width:80
    },
    input:{
      borderWidth: 1,
      borderColor: 'gray',
      borderRadius: 1,
      fontSize: 18,
      color: '#000000',
     padding: 15,
      marginBottom: 10,
      height: 50,
      borderRadius:10,
      marginLeft:10,
      marginRight:10

    }
});
export default Examples;

