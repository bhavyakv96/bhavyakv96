import React from 'react';
import {View,Text} from 'react-native';

const ApiDataInfo1=()=>{
    return(
    <View>
        <Text>
            Hellooo.......
        </Text>
    </View>
    );
};
export default ApiDataInfo1;