import React, { useState } from 'react';
import {View,Text,StyleSheet, TextInput} from 'react-native';
import { CheckBox } from 'react-native-elements'
//import {Checkbox} from 'native-base';
export default function RadioBtn(){
    const[male,setMale]=useState(false);
    const[female,setFemale]=useState(false);
    //const[other,setOther]=useState(false);

    const genderMale=()=>{
        setMale=true;
        setFemale=false;
    }
    const genderFemale=()=>{
        setMale=false;
        setFemale=true;
    }

    return(
        <View style={styles.container}>
            <TextInput
                placeholder="Enter your name"
                style={styles.msg}
            />
            <Checkbox
            title='Male'
            center
            checked={male}
            checkedIcon="dot-circle-o"
            uncheckedIcon="circle-o"
            onPress={genderMale}
            />
             <Checkbox
            title='Female'
            center
            checked={female}
            checkedIcon="dot-circle-o"
            uncheckedIcon="circle-o"
            onPress={genderFemale}
            />


        </View>
    )
}