import {StyleSheet} from 'react-native'

export default StyleSheet.create({
    container1:{
        flex:1,
        backgroundColor:'white',
        alignItems:'center',
        flexDirection:'row',
        alignSelf:'center',  
    
    },
    container2:{
        flex:1,
        backgroundColor:'white',
       //marginTop: 20,
        width: '90%',
        padding: 15,
        marginBottom: 10,
        marginLeft:20,
    },
    container3:{
        flex:1,
        backgroundColor:'white',
        alignItems:'center',
       },

    msg:{
        fontWeight:'bold',
        fontSize:36,
    },
    inputStyle: {
        borderWidth: 1,
        borderColor: '#000000',
        borderRadius: 18,
        fontSize: 18,
        color: '#000000',
        padding: 15,
        marginBottom: 10,
        height: 50,
    
      },
      loginBtn: {
        // backgroundColor: '#1589FF',
       // backgroundColor:'#1E90FF',
        backgroundColor:'#0AA6FE',
         height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop:20,
        marginBottom:15,
        borderRadius:30
      },

})

