import React from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
//import styles from './Screen2Style';

const BTabsTask3 = () => {
  return (
    <>
      <View style={styles.container1}>
        <Text style={styles.msg}>Imaginnovate</Text>
      </View>
      <View style={styles.container2}>
        <TextInput style={styles.inputStyle} placeholder=" Name" />
        <TextInput style={styles.inputStyle} placeholder=" Email" />
        <TextInput
          style={styles.inputStyle}
          placeholder="Password"
          secureTextEntry
        />
        <TextInput
          style={styles.inputStyle}
          placeholder="Confirm Password"
          secureTextEntry
        />

        <TouchableOpacity
          style={styles.loginBtn}
          onPress={() => alert('SignUp Works')}>
          <Text style={{color: 'white'}}>SIGN-UP</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container1: {
    flex: 1,
    // backgroundColor: 'white',
    alignItems: 'center',
    flexDirection: 'row',
    alignSelf: 'center',
  },
  container2: {
    flex: 3,
    //backgroundColor: 'white',
    marginBottom: 20,
    width: '90%',
    padding: 15,
    marginBottom: 30,
    marginLeft: 20,
  },
  msg: {
    fontWeight: 'bold',
    fontSize: 36,
  },
  inputStyle: {
    borderWidth: 1,
    borderColor: '#000000',
    borderRadius: 18,
    fontSize: 18,
    color: '#000000',
    padding: 15,
    marginBottom: 10,
    height: 50,
  },
  loginBtn: {
    backgroundColor: '#0AA6FE',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 15,
    borderRadius: 30,
  },
});

export default BTabsTask3;
