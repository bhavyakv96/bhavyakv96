import React from 'react';
import {Text, View, StyleSheet} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

import Signup from './components/Signup';
import Login from './components/Login';

function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={{alignSelf: 'center', fontSize: 24, color: '#7D0552'}}>
        Welcome to
      </Text>
      <Text style={{alignSelf: 'center', fontSize: 30, color: '#AA6C39'}}>
        Imaginnovate!!!!
      </Text>
    </View>
  );
}

function LoginScreen() {
  return <Login />;
}
function SignUpScreen() {
  return <Signup />;
}

const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="LogIn" component={LoginScreen} />
      <Tab.Screen name="SignUp" component={SignUpScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyTabs />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 12,
    //backgroundColor: 'powderblue',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
