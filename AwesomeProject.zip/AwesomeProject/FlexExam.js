import React from 'react';
import {StyleSheet, View} from 'react-native';
export default function App() {
  return (
    <>
      <View style={styles.container1}>
        <View style={styles.box1} />
      </View>
      <View style={styles.container1}>
        <View style={styles.box2} />
      </View>
      <View style={styles.container2}>
        <View style={styles.box3} />
        <View style={styles.box4} />
      </View>
    </>
  );
}
const styles = StyleSheet.create({
  container1: {
      flex:4,
    backgroundColor:'aliceblue'
  },
  box1: {
    backgroundColor:'skyblue',
    alignSelf: 'flex-end',
    width: 50,
    height: 50,
    margin: 4,
  },
  box2: {
    backgroundColor: 'powderblue',
    alignSelf: 'center',
    width: 50,
    height: 50,
    margin: 4,
  },
  container2: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems:'flex-end'
  },
  box3: {
    backgroundColor: 'steelblue',
    width: 50,
    height: 50,
    margin: 4,
  },
  box4: {
    backgroundColor: 'slategrey',
    width: 50,
    height: 50,
    margin: 4,
  },
});