import React from 'react';
import {View,Text, TouchableOpacity,StyleSheet} from 'react-native';

const TodoListCont = (props)=>{
    return(
        <View style={styles.item}>
            <View style={styles.content}>
                <TouchableOpacity style={styles.square}/>
                {/* <Text style={styles.itemText}>Item 1</Text> */}
                <Text style={styles.itemText}>{props.text}</Text>
         </View>
         <TouchableOpacity style={styles.circle}/>   
         </View>
    )
}

const styles=StyleSheet.create({
    item:{
    backgroundColor:'white',
    padding :15,
    borderRadius:10,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    marginBottom:20,
    },
    content:{
    flexDirection:'row',
    },
    square:{
    width:20,
    height:20,
    borderRadius:5,
    marginRight:15,
    opacity:0.4,
    backgroundColor:'skyblue'
    },
    itemText:{
    color:'black',
    fontSize:18
    },
    circle:{
    width:12,
    height:12,
    borderRadius:12,
    borderColor:'powderblue',
    borderWidth:2,
    },
})
export default TodoListCont;