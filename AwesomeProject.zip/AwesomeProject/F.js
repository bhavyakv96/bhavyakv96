import React from 'react';
import {View,StyleSheet, SafeAreaView} from 'react-native';

const FlexExam = () => {
    return (
      <SafeAreaView style={{flex:1}}>
      <View style={styles.container}>
        <View style={styles.orangeBox} />
        <View style={styles.whiteBox} />
        <View style={styles.greenBox} />
      </View>
      </SafeAreaView>
    );
   };
   // Style
   const styles = StyleSheet.create({
    container: {
      flex:3,
      flexDirection: 'row',
      justifyContent: 'flex-end',
      alignItems: 'flex-start',
      backgroundColor: '#454545',
    },
    orangeBox: {
      width: 80,
      height: 80,
      backgroundColor: 'orange',
    },
    whiteBox: {
      width: 80,
      height: 80,
      backgroundColor: 'pink',
    },
    greenBox: {
      width: 80,
      height: 80,
      backgroundColor: 'blue',
    },
   });
   export default FlexExam;