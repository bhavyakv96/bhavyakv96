import React from 'react';
import {View,Text, SafeAreaView,StyleSheet,TextInput, Button, TouchableOpacity} from 'react-native';
const Task =()=>{
    return(
        <>
       <View style={styles.container}>


        
        
        </View>
    
    
    
    
    
    
      <View style={style.container}>
        <TextInput style={style.input} placeholder="Input Text" />
        <TouchableOpacity
            onPress={() => alert('Added')}>
            <Text style={style.btnTxt}>Add</Text>
          </TouchableOpacity>
      </View>
        </>
    );
};
const styles = StyleSheet.create({
    container: {
      backgroundColor: 'aliceblue',
      flex: 11,
    },
  });
  const style = StyleSheet.create({
    container: {
      backgroundColor: '#ffff',
      flex: 1,
      flexDirection: 'row',
    },
    input: {
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 1,
        fontSize: 18,
        color: '#000000',
        padding: 15,
        marginBottom: 10,
        height: 50,
        borderRadius: 10,
        marginLeft: 10,
        marginRight: 10,
        width: 300,
      },
      btnTxt: {
        fontSize: 24,
        color: '#000000',
        paddingTop: 10,
      },
    });    
export default Task;